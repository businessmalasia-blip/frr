"""
In-memory буфер последних цен по каждому символу.

Сознательно хранит только цену (не объём — объём считается отдельно на
уровне 2 через REST klines, см. deep_analyzer.py). Это и есть та экономия
памяти, которая позволяет держать 200 пар на 2GB RAM: deque с maxlen сам
ограничивает рост, точки добавляются не чаще, чем раз в
price_sample_min_interval_sec секунд, чтобы не раздувать буфер при частых
апдейтах miniTicker.
"""

import time
from collections import deque
from typing import Optional

from config import CONFIG


class PriceBuffer:
    def __init__(self) -> None:
        self._buffers: dict[str, deque] = {}

    def add_price(self, symbol: str, price: float, ts: Optional[float] = None) -> None:
        ts = ts if ts is not None else time.time()
        buf = self._buffers.get(symbol)
        if buf is None:
            buf = deque(maxlen=CONFIG.price_buffer_maxlen)
            self._buffers[symbol] = buf

        if buf and (ts - buf[-1][0]) < CONFIG.price_sample_min_interval_sec:
            return  # слишком частый апдейт, пропускаем для экономии памяти

        buf.append((ts, price))

    def get_price_change_pct(self, symbol: str) -> Optional[float]:
        """
        % изменения цены за pump_lookback_minutes относительно самой старой
        точки в буфере, которая всё ещё попадает в окно. Возвращает None,
        если данных недостаточно (буфер только набирается после старта).
        """
        buf = self._buffers.get(symbol)
        if not buf or len(buf) < 2:
            return None

        now_ts, now_price = buf[-1]
        window_start = now_ts - CONFIG.pump_lookback_minutes * 60

        oldest_in_window = None
        for ts, price in buf:
            if ts >= window_start:
                oldest_in_window = (ts, price)
                break

        if oldest_in_window is None:
            return None

        _, base_price = oldest_in_window
        if base_price <= 0:
            return None

        return (now_price - base_price) / base_price * 100

    def drop_symbol(self, symbol: str) -> None:
        self._buffers.pop(symbol, None)

    def known_symbols(self) -> set[str]:
        return set(self._buffers.keys())
