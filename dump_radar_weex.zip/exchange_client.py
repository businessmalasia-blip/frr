"""
REST-клиент к WEEX Futures (Contract API v3).

Документация: https://www.weex.com/api-doc/contract/Market_API/GetKlines
Формат ответа klines у WEEX по индексам полей совпадает с тем, что было у
Binance (open_time, open, high, low, close, volume, close_time, quote_volume,
trades, taker_buy_base, taker_buy_quote), поэтому deep_analyzer.py менять не
пришлось — он читает klines по тем же индексам K_OPEN/K_HIGH/... .

Важное отличие от Binance: у /capi/v3/market/exchangeInfo нет явного поля
status (TRADING/BREAK) — считаем, что раз символ присутствует в ответе,
он торгуется. Это предположение стоит перепроверить на реальных данных:
если среди символов попадутся делистнутые/приостановленные пары без явного
маркера, whitelist будет включать мёртвые контракты, и это увидим по
ошибкам deep_analyzer (пустые klines) в логах.
"""

import aiohttp

from config import CONFIG


class ExchangeClient:
    def __init__(self, session: aiohttp.ClientSession):
        self._session = session
        self._base = CONFIG.weex_rest_base

    async def get_exchange_info(self) -> dict:
        """Список всех фьючерсных контрактов. symbol=None означает "все"."""
        url = f"{self._base}/capi/v3/market/exchangeInfo"
        async with self._session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def get_klines(self, symbol: str, interval: str, limit: int) -> list:
        """
        Возвращает свечи в том же позиционном формате, что использовался для
        Binance: [open_time, open, high, low, close, volume, close_time,
        quote_volume, trades, taker_buy_base, taker_buy_quote].
        WEEX ограничивает limit диапазоном 1-1000.
        """
        url = f"{self._base}/capi/v3/market/klines"
        params = {"symbol": symbol, "interval": interval, "limit": min(limit, 1000)}
        async with self._session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def get_current_price(self, symbol: str) -> float:
        """
        GET /capi/v3/market/symbolPrice — см.
        https://www.weex.com/api-doc/contract/Market_API/GetSymbolPrice
        По умолчанию priceType=INDEX; используется как REST-запасной вариант,
        в штатном режиме outcome_tracker читает цену из Redis-кэша, не отсюда.
        """
        url = f"{self._base}/capi/v3/market/symbolPrice"
        params = {"symbol": symbol}
        async with self._session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            data = await resp.json()
            return float(data["price"])


class CoinGeckoClient:
    """Без изменений относительно версии под Binance — CoinGecko не зависит от биржи."""

    def __init__(self, session: aiohttp.ClientSession):
        self._session = session
        self._base = CONFIG.coingecko_base

    async def get_symbols_with_min_market_cap(self, min_cap_usd: float) -> set[str]:
        result: set[str] = set()
        page = 1
        per_page = 250
        url = f"{self._base}/coins/markets"

        while True:
            params = {
                "vs_currency": "usd",
                "order": "market_cap_desc",
                "per_page": per_page,
                "page": page,
                "sparkline": "false",
            }
            async with self._session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                resp.raise_for_status()
                data = await resp.json()

            if not data:
                break

            stop = False
            for coin in data:
                cap = coin.get("market_cap") or 0
                if cap < min_cap_usd:
                    stop = True
                    break
                symbol = coin.get("symbol", "").upper()
                if symbol:
                    result.add(symbol)

            if stop or len(data) < per_page:
                break
            page += 1

        return result
