"""
Связующее звено между deep_analyzer и хранилищем. Порядок операций важен:

1. Сначала пытаемся атомарно захватить dedup-ключ в Redis (SET NX).
   Если не получилось — по этой монете уже был сигнал в последние 15 минут,
   выходим, ничего не пишем.
2. Пишем сигнал в SQLite (единственный источник правды).
3. Публикуем signal_id в pub/sub — если Redis в этот момент недоступен,
   сигнал всё равно не теряется: он уже в SQLite, telegram_notifier
   подхватит его через периодический fallback-опрос БД.
"""

import logging
import time

from config import CONFIG
from db import insert_signal
from deep_analyzer import SignalCandidate
from redis_client import RedisClient

logger = logging.getLogger("signal_writer")


async def write_signal(candidate: SignalCandidate, redis_client: RedisClient) -> None:
    claimed = await redis_client.try_claim_dedup(candidate.symbol)
    if not claimed:
        logger.info("signal for %s suppressed by dedup", candidate.symbol)
        return

    signal_row = {
        "symbol": candidate.symbol,
        "ts_signal": int(time.time()),
        "price_change_pct": candidate.price_change_pct,
        "volume_multiplier": candidate.volume_multiplier,
        "vwap_deviation_pct": candidate.vwap_deviation_pct,
        "entry_price": candidate.entry_price,
        "stop_price": candidate.stop_price,
        "tp1_price": candidate.tp1_price,
        "tp2_price": candidate.tp2_price,
        "tp3_price": candidate.tp3_price,
    }

    signal_id = await insert_signal(CONFIG.sqlite_path, signal_row)
    logger.info("signal #%d created for %s at %.6f", signal_id, candidate.symbol, candidate.entry_price)

    try:
        await redis_client.publish_new_signal(signal_id)
    except Exception:
        # Публикация — не критичный путь, сигнал уже в SQLite.
        logger.warning("failed to publish signal #%d to pub/sub, notifier will pick it up via fallback poll", signal_id, exc_info=True)
