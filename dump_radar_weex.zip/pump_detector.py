"""
Уровень 1 детектора: чистая, не блокирующая I/O проверка "не разогналась
ли монета за последние N минут". Работает только с тем, что уже есть в
PriceBuffer — никаких сетевых вызовов, чтобы не тормозить основной цикл
чтения WebSocket. Подтверждение по объёму/VWAP/триггеру — задача
deep_analyzer.py, вызываемого только для кандидатов, прошедших этот фильтр.
"""

from typing import Optional

from config import CONFIG
from rolling_buffer import PriceBuffer


def check_pump_candidate(symbol: str, buffer: PriceBuffer) -> Optional[float]:
    """
    Возвращает price_change_pct, если символ прошёл порог пампа,
    иначе None.
    """
    change_pct = buffer.get_price_change_pct(symbol)
    if change_pct is None:
        return None
    if change_pct >= CONFIG.pump_price_change_pct:
        return change_pct
    return None
