"""
Точка входа процесса market_watcher — версия под WEEX Futures.

Отличие от Binance-версии: вместо одного MiniTickerClient запускается
WeexMarketClient — супервизор, который поднимает несколько параллельных
WS-соединений (по чанкам символов, лимит 100 каналов на соединение у WEEX).
"""

import asyncio
import logging
import os

import aiohttp

from config import CONFIG
from db import init_db
from redis_client import RedisClient
from symbol_universe import symbol_universe_loop
from ws_client import WeexMarketClient

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("main")


async def main() -> None:
    os.makedirs(os.path.dirname(CONFIG.sqlite_path) or ".", exist_ok=True)
    await init_db(CONFIG.sqlite_path)

    redis_client = RedisClient()

    async with aiohttp.ClientSession() as http_session:
        market_client = WeexMarketClient(redis_client, http_session)

        try:
            await asyncio.gather(
                symbol_universe_loop(http_session, redis_client),
                market_client.run_forever(),
            )
        finally:
            await redis_client.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("shutting down market_watcher")
