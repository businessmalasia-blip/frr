"""
Тонкая обёртка над Redis. Redis тут используется строго в лёгкой роли:
дедупликация сигналов, whitelist монет, кэш последней цены (с timestamp
внутри значения, а не через TTL — см. обоснование в переписке) и
pub/sub-уведомление telegram_notifier.

Redis настраивается снаружи (redis.conf) с maxmemory 64mb,
maxmemory-policy allkeys-lru, save "", appendonly no — без персистентности,
это не хранилище истины, а быстрый вспомогательный слой.
"""

import json
import time
from typing import Optional

import redis.asyncio as redis

from config import CONFIG

WHITELIST_KEY = "whitelist:symbols"
WHITELIST_UPDATED_KEY = "whitelist:updated_at"
SIGNALS_CHANNEL = "signals:new"


class RedisClient:
    def __init__(self, url: str = CONFIG.redis_url):
        self._client = redis.from_url(url, decode_responses=True)

    async def close(self) -> None:
        await self._client.close()

    # --- Дедупликация ---
    async def try_claim_dedup(self, symbol: str) -> bool:
        """
        Атомарно пытается поставить дедуп-ключ для символа.
        Возвращает True, если ключа не было (можно создавать сигнал),
        False — если сигнал по этой монете уже был в последние N минут.
        """
        key = f"dedup:{symbol}"
        result = await self._client.set(key, "1", ex=CONFIG.dedup_ttl_sec, nx=True)
        return bool(result)

    # --- Whitelist монет ---
    async def set_whitelist(self, symbols: set[str]) -> None:
        pipe = self._client.pipeline()
        pipe.delete(WHITELIST_KEY)
        if symbols:
            pipe.sadd(WHITELIST_KEY, *symbols)
        pipe.set(WHITELIST_UPDATED_KEY, str(int(time.time())))
        await pipe.execute()

    async def get_whitelist(self) -> set[str]:
        members = await self._client.smembers(WHITELIST_KEY)
        return set(members)

    async def is_whitelisted(self, symbol: str) -> bool:
        return bool(await self._client.sismember(WHITELIST_KEY, symbol))

    # --- Кэш цены: JSON {"price": ..., "ts": ...}, TTL как подстраховка от раздувания, не как маркер свежести ---
    async def set_price(self, symbol: str, price: float) -> None:
        payload = json.dumps({"price": price, "ts": time.time()})
        await self._client.set(f"price:{symbol}", payload, ex=CONFIG.price_cache_ttl_sec)

    async def get_price(self, symbol: str) -> Optional[dict]:
        """
        Возвращает {"price": float, "ts": float} или None, если данных нет.
        Проверку свежести (age > price_stale_after_sec) делает вызывающий код —
        здесь только чтение, чтобы не смешивать ответственность.
        """
        raw = await self._client.get(f"price:{symbol}")
        if raw is None:
            return None
        return json.loads(raw)

    # --- Pub/Sub уведомление ---
    async def publish_new_signal(self, signal_id: int) -> None:
        await self._client.publish(SIGNALS_CHANNEL, json.dumps({"signal_id": signal_id}))
