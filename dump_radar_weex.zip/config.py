"""
Конфигурация Dump Radar (market_watcher) — версия под WEEX Futures.

Пороги идентичны согласованным ранее (пункты 1-3 не менялись при переезде
с Binance) — поменялись только базовые URL биржи в самом низу файла.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class ScannerConfig:
    # --- Уровень 1: дешёвый ценовой фильтр по всем парам ---
    pump_lookback_minutes: int = 15
    pump_price_change_pct: float = 8.0
    price_sample_min_interval_sec: int = 5
    price_buffer_maxlen: int = int((15 * 60 / 5) * 1.2)  # ~216 точек на символ

    # --- Уровень 2: точный анализ по кандидатам (REST) ---
    volume_avg_windows: int = 96             # 96 x 15m = 24 часа истории для среднего объёма
    volume_multiplier_threshold: float = 3.0
    vwap_window_minutes: int = 60
    vwap_deviation_pct_threshold: float = 5.0

    # --- Триггер на шорт ---
    trigger_timeframe: str = "1m"
    trigger_lookback_candles: int = 20

    # --- Стоп / тейки ---
    stop_pct: float = 2.5
    tp1_rr: float = 1.5
    tp2_rr: float = 2.5
    tp3_rr: float = 4.0

    # --- Вселенная монет ---
    min_market_cap_usd: float = 100_000_000.0
    max_monitored_symbols: int = 200
    symbol_universe_refresh_hours: int = 24

    # --- Дедупликация / TTL ---
    dedup_ttl_sec: int = pump_lookback_minutes * 60
    price_cache_ttl_sec: int = 600
    price_stale_after_sec: int = 60

    # --- outcome_tracker ---
    outcome_check_interval_sec: int = 30
    signal_timeout_hours: int = 24

    # --- Инфраструктура: WEEX Futures ---
    # REST: https://www.weex.com/api-doc/contract/Market_API/GetKlines
    # WS:   https://www.weex.com/api-doc/contract/Websocket/websocket-intro
    weex_rest_base: str = "https://api-contract.weex.com"
    weex_ws_public_url: str = "wss://ws-contract.weex.com/v3/ws/public"
    coingecko_base: str = "https://api.coingecko.com/api/v3"

    redis_url: str = "redis://localhost:6379/0"
    redis_maxmemory: str = "64mb"

    sqlite_path: str = "./data/dump_radar.db"

    reconnect_backoff_start_sec: float = 1.0
    reconnect_backoff_max_sec: float = 60.0
    ws_health_check_interval_sec: int = 30
    ws_silence_timeout_sec: int = 45

    # WEEX ожидает Pong-ответ на серверный Ping в формате {"method":"PONG","id":1}
    # см. https://www.weex.com/api-doc/contract/Websocket/websocket-intro
    ws_pong_response: str = '{"method":"PONG","id":1}'

    # Максимум подписок на одно соединение согласно документации WEEX
    ws_max_channels_per_connection: int = 100


CONFIG = ScannerConfig()
