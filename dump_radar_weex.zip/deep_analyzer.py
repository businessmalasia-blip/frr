"""
Уровень 2 детектора: вызывается только для кандидатов, прошедших дешёвый
ценовой фильтр уровня 1 (pump_detector). Здесь делаются точечные REST-запросы
к бирже — по объёму их немного (единицы кандидатов за раз, а не 200 пар
постоянно), поэтому REST здесь оправдан и не создаёт нагрузки, о которой
предупреждали в архитектуре.

Три проверки, все должны подтвердиться, чтобы сигнал состоялся:
1. Объём за последние 15 минут >= volume_multiplier_threshold * среднего
   объёма 15-минутных окон за последние 24 часа.
2. Отклонение цены от VWAP (окно vwap_window_minutes) >= порога.
3. Триггер разворота: первая свеча (1m/3m) после локального пика,
   закрывшаяся ниже минимума предыдущей свечи.

Асинхронно, через aiohttp — синхронных вызовов быть не должно.
"""

import logging
from dataclasses import dataclass
from typing import Optional

import aiohttp

from config import CONFIG
from exchange_client import ExchangeClient

logger = logging.getLogger("deep_analyzer")

# Индексы полей в kline от Binance: [open_time, open, high, low, close, volume, close_time, quote_volume, ...]
K_OPEN_TIME, K_OPEN, K_HIGH, K_LOW, K_CLOSE, K_VOLUME, K_CLOSE_TIME, K_QUOTE_VOLUME = range(8)


@dataclass
class SignalCandidate:
    symbol: str
    price_change_pct: float
    volume_multiplier: float
    vwap_deviation_pct: float
    entry_price: float
    stop_price: float
    tp1_price: float
    tp2_price: float
    tp3_price: float


async def _check_volume(exchange: ExchangeClient, symbol: str) -> Optional[float]:
    """
    Возвращает volume_multiplier, если объём за последние 15 минут
    подтверждает порог, иначе None.

    avg считается по volume_avg_windows завершённых 15m свечей (последняя,
    ещё формирующаяся, исключается из базы усреднения и используется
    отдельно как "текущий объём").
    """
    klines = await exchange.get_klines(symbol, interval="15m", limit=CONFIG.volume_avg_windows + 1)
    if len(klines) < 2:
        return None

    *history, current = klines
    avg_volume = sum(float(k[K_VOLUME]) for k in history) / len(history)
    if avg_volume <= 0:
        return None

    current_volume = float(current[K_VOLUME])
    multiplier = current_volume / avg_volume

    if multiplier >= CONFIG.volume_multiplier_threshold:
        return multiplier
    return None


async def _check_vwap(exchange: ExchangeClient, symbol: str, current_price: float) -> Optional[float]:
    """
    VWAP за vwap_window_minutes на 1-минутных свечах.
    Возвращает % отклонения текущей цены от VWAP, если он превышает порог.
    """
    klines = await exchange.get_klines(symbol, interval="1m", limit=CONFIG.vwap_window_minutes)
    if not klines:
        return None

    total_pv = 0.0
    total_v = 0.0
    for k in klines:
        typical_price = (float(k[K_HIGH]) + float(k[K_LOW]) + float(k[K_CLOSE])) / 3
        volume = float(k[K_VOLUME])
        total_pv += typical_price * volume
        total_v += volume

    if total_v <= 0:
        return None

    vwap = total_pv / total_v
    if vwap <= 0:
        return None

    deviation_pct = (current_price - vwap) / vwap * 100

    if deviation_pct >= CONFIG.vwap_deviation_pct_threshold:
        return deviation_pct
    return None


async def _check_trigger(exchange: ExchangeClient, symbol: str) -> Optional[dict]:
    """
    Ищет локальный пик среди последних trigger_lookback_candles свечей
    trigger_timeframe, затем проверяет, что первая свеча после пика
    закрылась ниже минимума предыдущей свечи (сигнал на шорт).

    Возвращает словарь с entry/high точками при подтверждении, иначе None.
    """
    klines = await exchange.get_klines(
        symbol, interval=CONFIG.trigger_timeframe, limit=CONFIG.trigger_lookback_candles
    )
    if len(klines) < 3:
        return None

    highs = [float(k[K_HIGH]) for k in klines]
    peak_idx = max(range(len(highs)), key=lambda i: highs[i])

    # Пик не должен быть последней свечой — нужна хотя бы одна свеча после него для проверки триггера
    if peak_idx >= len(klines) - 1:
        return None

    prev_candle = klines[peak_idx]
    trigger_candle = klines[peak_idx + 1]

    prev_low = float(prev_candle[K_LOW])
    trigger_close = float(trigger_candle[K_CLOSE])

    if trigger_close < prev_low:
        return {
            "entry_price": trigger_close,
            "peak_price": highs[peak_idx],
        }
    return None


async def analyze_candidate(
    session: aiohttp.ClientSession,
    symbol: str,
    price_change_pct: float,
) -> Optional[SignalCandidate]:
    """
    Полная проверка кандидата уровня 2. Возвращает SignalCandidate только
    если ВСЕ три условия подтвердились, иначе None (сигнал не создаётся).
    """
    exchange = ExchangeClient(session)

    try:
        trigger = await _check_trigger(exchange, symbol)
        if trigger is None:
            return None

        entry_price = trigger["entry_price"]

        volume_multiplier = await _check_volume(exchange, symbol)
        if volume_multiplier is None:
            return None

        vwap_deviation_pct = await _check_vwap(exchange, symbol, entry_price)
        if vwap_deviation_pct is None:
            return None

    except aiohttp.ClientError:
        logger.warning("deep analysis network error for %s", symbol, exc_info=True)
        return None

    stop_price = entry_price * (1 + CONFIG.stop_pct / 100)
    risk = stop_price - entry_price

    tp1_price = entry_price - risk * CONFIG.tp1_rr
    tp2_price = entry_price - risk * CONFIG.tp2_rr
    tp3_price = entry_price - risk * CONFIG.tp3_rr

    return SignalCandidate(
        symbol=symbol,
        price_change_pct=price_change_pct,
        volume_multiplier=volume_multiplier,
        vwap_deviation_pct=vwap_deviation_pct,
        entry_price=entry_price,
        stop_price=stop_price,
        tp1_price=tp1_price,
        tp2_price=tp2_price,
        tp3_price=tp3_price,
    )
