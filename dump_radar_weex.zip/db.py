"""
Слой доступа к SQLite. SQLite — единственный источник правды по сигналам,
поэтому все процессы (market_watcher, telegram_notifier, outcome_tracker)
подключаются к одному и тому же файлу с WAL-режимом, что позволяет
одновременное чтение и запись из разных процессов без блокировок.
"""

import time
import aiosqlite

SCHEMA = """
CREATE TABLE IF NOT EXISTS signals (
    signal_id            INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol                TEXT NOT NULL,
    ts_signal             INTEGER NOT NULL,
    price_change_pct      REAL NOT NULL,
    volume_multiplier     REAL NOT NULL,
    vwap_deviation_pct    REAL NOT NULL,
    entry_price           REAL NOT NULL,
    stop_price            REAL NOT NULL,
    tp1_price             REAL NOT NULL,
    tp2_price             REAL NOT NULL,
    tp3_price             REAL NOT NULL,
    status                TEXT NOT NULL DEFAULT 'open',   -- 'open' | 'closed'
    outcome               TEXT,                            -- NULL пока open; далее tp1_hit/tp2_hit/tp3_hit/stop_hit/timeout_no_hit
    ts_outcome            INTEGER,
    time_to_outcome_min   REAL,
    mfe_pct               REAL NOT NULL DEFAULT 0,
    mae_pct               REAL NOT NULL DEFAULT 0,
    last_checked_ts       INTEGER,
    notified              INTEGER NOT NULL DEFAULT 0,      -- 0/1: отправлен ли алерт в Telegram
    created_at            INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_signals_status ON signals(status);
CREATE INDEX IF NOT EXISTS idx_signals_symbol ON signals(symbol);
CREATE INDEX IF NOT EXISTS idx_signals_ts_signal ON signals(ts_signal);
"""


async def init_db(db_path: str) -> None:
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA journal_mode=WAL;")
        await db.executescript(SCHEMA)
        await db.commit()


async def insert_signal(db_path: str, signal: dict) -> int:
    """
    Вставляет новый сигнал. signal — словарь с ключами, соответствующими
    колонкам (кроме signal_id, status, outcome, ts_outcome, last_checked_ts —
    они либо автоинкремент, либо выставляются дефолтами/позже).
    Возвращает signal_id вставленной записи.
    """
    now = int(time.time())
    async with aiosqlite.connect(db_path) as db:
        cursor = await db.execute(
            """
            INSERT INTO signals (
                symbol, ts_signal, price_change_pct, volume_multiplier,
                vwap_deviation_pct, entry_price, stop_price,
                tp1_price, tp2_price, tp3_price, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                signal["symbol"],
                signal["ts_signal"],
                signal["price_change_pct"],
                signal["volume_multiplier"],
                signal["vwap_deviation_pct"],
                signal["entry_price"],
                signal["stop_price"],
                signal["tp1_price"],
                signal["tp2_price"],
                signal["tp3_price"],
                now,
            ),
        )
        await db.commit()
        return cursor.lastrowid
