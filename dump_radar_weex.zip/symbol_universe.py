"""
Формирование и периодическое обновление whitelist отслеживаемых пар — версия
под WEEX Futures.

Отличие от Binance-версии: у /capi/v3/market/exchangeInfo нет поля status
(TRADING/BREAK), поэтому фильтруем по forwardContractFlag == True (USDT-
маржинальный контракт) и quoteAsset == "USDT". Если по факту в список
попадут делистнутые контракты — это будет видно по систематическим ошибкам
deep_analyzer (пустой ответ klines) в логах, тогда добавим доп. фильтр.
"""

import asyncio
import logging

import aiohttp

from config import CONFIG
from exchange_client import ExchangeClient, CoinGeckoClient
from redis_client import RedisClient

logger = logging.getLogger("symbol_universe")


async def build_whitelist(session: aiohttp.ClientSession) -> set[str]:
    exchange = ExchangeClient(session)
    coingecko = CoinGeckoClient(session)

    exchange_info = await exchange.get_exchange_info()
    active_symbols = {
        s["symbol"]
        for s in exchange_info.get("symbols", [])
        if s.get("quoteAsset") == "USDT" and s.get("forwardContractFlag") is True
    }

    large_cap_bases = await coingecko.get_symbols_with_min_market_cap(CONFIG.min_market_cap_usd)

    matched = set()
    for symbol in active_symbols:
        base = symbol.removesuffix("USDT")
        if base in large_cap_bases:
            matched.add(symbol)

    if len(matched) > CONFIG.max_monitored_symbols:
        matched = set(sorted(matched)[: CONFIG.max_monitored_symbols])

    logger.info(
        "symbol universe built: %d active perpetuals, %d large-cap matches, %d after limit",
        len(active_symbols), len(large_cap_bases & {s.removesuffix('USDT') for s in active_symbols}), len(matched),
    )
    return matched


async def symbol_universe_loop(session: aiohttp.ClientSession, redis_client: RedisClient) -> None:
    while True:
        try:
            whitelist = await build_whitelist(session)
            if whitelist:
                await redis_client.set_whitelist(whitelist)
            else:
                logger.warning("built empty whitelist, keeping previous one in Redis")
        except Exception:
            logger.exception("failed to refresh symbol universe, keeping previous whitelist")

        await asyncio.sleep(CONFIG.symbol_universe_refresh_hours * 3600)
