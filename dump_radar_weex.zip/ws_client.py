"""
WebSocket-клиент к WEEX Futures Public канал: wss://ws-contract.weex.com/v3/ws/public

Ключевое архитектурное отличие от Binance-версии: у WEEX нет единого
комбинированного потока по всем парам сразу (аналога !miniTicker@arr).
Подписка идёт по отдельным каналам "<symbol>@ticker", а документация
ограничивает одно соединение 100 каналами максимум. При whitelist до 200
символов это значит минимум 2 параллельных WS-соединения, разбитых на
чанки — реализовано через WeexTickerConnection (одно соединение на чанк)
и супервизор WeexMarketClient, который их запускает и перезапускает при
смене whitelist.

Формат push-сообщения ticker:
{"e":"ticker","E":<ms>,"s":"BTCUSDT","d":[{"c": "<last price>", ...}]}
Используем только "d"[0]["c"] — это и есть цена, аналог "c" в Binance miniTicker.

Сервер шлёт периодические Ping {"event":"ping","time":...}, на которые нужно
отвечать фиксированным Pong {"method":"PONG","id":1} — иначе после 10
пропущенных ответов сервер сам закрывает соединение (см. документацию).
"""

import asyncio
import json
import logging
import time

import aiohttp
import websockets
from websockets.exceptions import ConnectionClosed

from config import CONFIG
from deep_analyzer import analyze_candidate
from pump_detector import check_pump_candidate
from redis_client import RedisClient
from rolling_buffer import PriceBuffer
from signal_writer import write_signal

logger = logging.getLogger("ws_client")

WHITELIST_CHECK_INTERVAL_SEC = 60


def _chunk(items: list, size: int) -> list[list]:
    return [items[i:i + size] for i in range(0, len(items), size)]


class WeexTickerConnection:
    """Одно WS-соединение, обслуживающее подписку на чанк символов (<=100)."""

    def __init__(
        self,
        symbols: list[str],
        buffer: PriceBuffer,
        redis_client: RedisClient,
        http_session: aiohttp.ClientSession,
        conn_label: str,
    ):
        self._symbols = symbols
        self._buffer = buffer
        self._redis = redis_client
        self._http_session = http_session
        self._label = conn_label
        self._last_message_ts = 0.0
        self._in_flight: set[str] = set()

    async def _handle_candidate(self, symbol: str, price_change_pct: float) -> None:
        if symbol in self._in_flight:
            return
        self._in_flight.add(symbol)
        try:
            candidate = await analyze_candidate(self._http_session, symbol, price_change_pct)
            if candidate is not None:
                await write_signal(candidate, self._redis)
        except Exception:
            logger.exception("[%s] unhandled error analyzing candidate %s", self._label, symbol)
        finally:
            self._in_flight.discard(symbol)

    async def _process_message(self, ws, raw_message: str) -> None:
        self._last_message_ts = time.time()

        try:
            payload = json.loads(raw_message)
        except json.JSONDecodeError:
            logger.warning("[%s] failed to decode ws message, skipping", self._label)
            return

        # Серверный ping — обязателен ответ фиксированным Pong, иначе сервер разорвёт соединение
        if payload.get("event") == "ping":
            await ws.send(CONFIG.ws_pong_response)
            return

        if payload.get("e") != "ticker":
            return  # подтверждения подписки и прочий служебный трафик игнорируем

        symbol = payload.get("s")
        entries = payload.get("d")
        if not symbol or not entries:
            return

        close_price = entries[0].get("c")
        if close_price is None:
            return

        price = float(close_price)
        self._buffer.add_price(symbol, price)

        try:
            await self._redis.set_price(symbol, price)
        except Exception:
            logger.warning("[%s] failed to update price cache for %s", self._label, symbol, exc_info=True)

        price_change_pct = check_pump_candidate(symbol, self._buffer)
        if price_change_pct is not None:
            asyncio.create_task(self._handle_candidate(symbol, price_change_pct))

    async def _subscribe(self, ws) -> None:
        params = [f"{symbol}@ticker" for symbol in self._symbols]
        request = {"method": "SUBSCRIBE", "params": params, "id": 1}
        await ws.send(json.dumps(request))

        # Ждём подтверждение подписки, не блокируя дольше нескольких секунд
        try:
            ack_raw = await asyncio.wait_for(ws.recv(), timeout=10)
            ack = json.loads(ack_raw)
            if ack.get("result") is not True:
                logger.warning("[%s] subscription not confirmed: %s", self._label, ack)
        except (asyncio.TimeoutError, json.JSONDecodeError):
            logger.warning("[%s] no clean subscription ack received, continuing anyway", self._label)

    async def _health_check_loop(self, ws) -> None:
        while True:
            await asyncio.sleep(CONFIG.ws_health_check_interval_sec)
            silence = time.time() - self._last_message_ts
            if silence > CONFIG.ws_silence_timeout_sec:
                logger.warning("[%s] no ws messages for %.0fs, forcing reconnect", self._label, silence)
                await ws.close()
                return

    async def run_forever(self) -> None:
        backoff = CONFIG.reconnect_backoff_start_sec

        while True:
            try:
                logger.info("[%s] connecting, %d symbols", self._label, len(self._symbols))
                async with websockets.connect(
                    CONFIG.weex_ws_public_url, ping_interval=None
                ) as ws:
                    # ping_interval=None: WEEX сам шлёт прикладные ping {"event":"ping",...},
                    # отвечаем на них вручную в _process_message — не полагаемся на встроенный
                    # протокольный ping/pong websockets, чтобы не дублировать механизмы.
                    self._last_message_ts = time.time()
                    backoff = CONFIG.reconnect_backoff_start_sec

                    await self._subscribe(ws)

                    health_task = asyncio.create_task(self._health_check_loop(ws))
                    try:
                        async for message in ws:
                            await self._process_message(ws, message)
                    finally:
                        health_task.cancel()

            except (ConnectionClosed, OSError) as exc:
                logger.warning("[%s] ws connection lost (%s), reconnecting in %.1fs", self._label, exc, backoff)
            except Exception:
                logger.exception("[%s] unexpected ws error, reconnecting in %.1fs", self._label, backoff)

            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, CONFIG.reconnect_backoff_max_sec)


class WeexMarketClient:
    """
    Супервизор: читает whitelist из Redis, разбивает на чанки по
    ws_max_channels_per_connection, держит по одному WeexTickerConnection на
    чанк. При изменении whitelist (проверяется раз в минуту) — полностью
    пересоздаёт все соединения с новым списком символов.
    """

    def __init__(self, redis_client: RedisClient, http_session: aiohttp.ClientSession):
        self._redis = redis_client
        self._http_session = http_session
        self._buffer = PriceBuffer()

    async def _wait_for_whitelist(self) -> list[str]:
        """Блокируется, пока whitelist не появится (на случай гонки со стартом symbol_universe)."""
        while True:
            whitelist = await self._redis.get_whitelist()
            if whitelist:
                return sorted(whitelist)
            logger.info("whitelist is empty yet, waiting for symbol_universe to populate it...")
            await asyncio.sleep(5)

    async def run_forever(self) -> None:
        while True:
            symbols = await self._wait_for_whitelist()
            chunks = _chunk(symbols, CONFIG.ws_max_channels_per_connection)
            logger.info("starting %d ws connection(s) for %d symbols", len(chunks), len(symbols))

            connections = [
                WeexTickerConnection(chunk, self._buffer, self._redis, self._http_session, conn_label=f"conn-{i}")
                for i, chunk in enumerate(chunks)
            ]
            tasks = [asyncio.create_task(conn.run_forever()) for conn in connections]

            # Ждём либо падения одной из задач (не должно происходить, run_forever сам себя чинит),
            # либо сигнала о смене whitelist — проверяем периодически.
            whitelist_snapshot = set(symbols)
            try:
                while True:
                    await asyncio.sleep(WHITELIST_CHECK_INTERVAL_SEC)
                    current = await self._redis.get_whitelist()
                    if current and current != whitelist_snapshot:
                        logger.info("whitelist changed, restarting ws connections")
                        break
            finally:
                for task in tasks:
                    task.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
