"""
Конфигурация Dump Radar (market_watcher).

Все пороги, согласованные в ходе обсуждения, собраны здесь одним местом.
Ничего из перечисленного не должно быть захардкожено в логике модулей —
если понадобится подкрутить параметры по результатам теста, правим только этот файл.
"""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ScannerConfig:
    # --- Уровень 1: дешёвый ценовой фильтр по всем парам ---
    pump_lookback_minutes: int = 15          # окно, за которое считаем % роста
    pump_price_change_pct: float = 8.0       # порог роста цены для кандидата в перегретые
    price_sample_min_interval_sec: int = 5   # не чаще, чем раз в N сек добавляем точку в буфер цены
    # Буфер должен покрывать pump_lookback_minutes с запасом (x1.2) на случай неравномерных апдейтов
    price_buffer_maxlen: int = int((15 * 60 / 5) * 1.2)  # ~216 точек на символ

    # --- Уровень 2: точный анализ по кандидатам (REST) ---
    volume_avg_windows: int = 96             # 96 x 15m = 24 часа истории для среднего объёма
    volume_multiplier_threshold: float = 3.0 # текущий объём за 15 мин >= X * среднего
    vwap_window_minutes: int = 60            # окно для расчёта VWAP
    vwap_deviation_pct_threshold: float = 5.0

    # --- Триггер на шорт ---
    trigger_timeframe: str = "1m"            # "1m" или "3m"
    trigger_lookback_candles: int = 20       # сколько последних свечей смотрим в поисках локального пика

    # --- Стоп / тейки (в % от цены входа, для шорта: стоп выше входа, тейки ниже) ---
    stop_pct: float = 2.5
    tp1_rr: float = 1.5   # risk:reward
    tp2_rr: float = 2.5
    tp3_rr: float = 4.0

    # --- Вселенная монет ---
    min_market_cap_usd: float = 100_000_000.0
    max_monitored_symbols: int = 200
    symbol_universe_refresh_hours: int = 24

    # --- Дедупликация / TTL ---
    dedup_ttl_sec: int = pump_lookback_minutes * 60  # 900 сек = 15 минут
    price_cache_ttl_sec: int = 600                   # подстраховка от раздувания Redis, не основной механизм свежести
    price_stale_after_sec: int = 60                  # после этого outcome_tracker считает цену устаревшей

    # --- outcome_tracker ---
    outcome_check_interval_sec: int = 30
    signal_timeout_hours: int = 24

    # --- Инфраструктура ---
    binance_fapi_base: str = "https://fapi.binance.com"
    binance_ws_base: str = "wss://fstream.binance.com/ws"
    coingecko_base: str = "https://api.coingecko.com/api/v3"

    redis_url: str = "redis://localhost:6379/0"
    redis_maxmemory: str = "64mb"

    sqlite_path: str = "./data/dump_radar.db"

    reconnect_backoff_start_sec: float = 1.0
    reconnect_backoff_max_sec: float = 60.0
    ws_health_check_interval_sec: int = 30
    ws_silence_timeout_sec: int = 45  # если тишина дольше — форсируем reconnect


CONFIG = ScannerConfig()
