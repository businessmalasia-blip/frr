"""
Подключение к комбинированному потоку !miniTicker@arr Binance Futures —
одно сообщение в секунду со сводкой по ВСЕМ парам сразу (цена, 24h объём).
Это и есть уровень 1: дёшево, без отдельной подписки на каждый символ.

Жёсткое требование архитектуры: обработка входящего сообщения должна быть
максимально лёгкой. Всё, что требует сети (deep_analyzer), уходит в фон
через asyncio.create_task и не блокирует чтение следующего сообщения.

Whitelist кэшируется локально в процессе и обновляется из Redis раз в
whitelist_refresh_sec, а не на каждое сообщение — иначе 200+ проверок в
секунду создавали бы лишнюю нагрузку на Redis без необходимости (whitelist
меняется не чаще раза в сутки).
"""

import asyncio
import json
import logging
import time

import aiohttp
import websockets
from websockets.exceptions import ConnectionClosed

from config import CONFIG
from deep_analyzer import analyze_candidate
from pump_detector import check_pump_candidate
from redis_client import RedisClient
from rolling_buffer import PriceBuffer
from signal_writer import write_signal

logger = logging.getLogger("ws_client")

STREAM_URL = f"{CONFIG.binance_ws_base}/!miniTicker@arr"
WHITELIST_REFRESH_SEC = 60


class MiniTickerClient:
    def __init__(self, redis_client: RedisClient, http_session: aiohttp.ClientSession):
        self._redis = redis_client
        self._http_session = http_session
        self._buffer = PriceBuffer()
        self._whitelist: set[str] = set()
        self._whitelist_loaded_at: float = 0.0
        self._last_message_ts: float = 0.0
        self._in_flight: set[str] = set()  # символы, по которым уже запущен deep_analyzer, чтобы не дублировать задачи

    async def _refresh_whitelist_if_needed(self) -> None:
        now = time.time()
        if now - self._whitelist_loaded_at < WHITELIST_REFRESH_SEC:
            return
        try:
            self._whitelist = await self._redis.get_whitelist()
            self._whitelist_loaded_at = now
        except Exception:
            logger.warning("failed to refresh whitelist from redis, keeping previous copy", exc_info=True)

    async def _handle_candidate(self, symbol: str, price_change_pct: float) -> None:
        if symbol in self._in_flight:
            return  # уже анализируется, не запускаем вторую параллельную проверку
        self._in_flight.add(symbol)
        try:
            candidate = await analyze_candidate(self._http_session, symbol, price_change_pct)
            if candidate is not None:
                await write_signal(candidate, self._redis)
        except Exception:
            logger.exception("unhandled error analyzing candidate %s", symbol)
        finally:
            self._in_flight.discard(symbol)

    async def _process_message(self, raw_message: str) -> None:
        self._last_message_ts = time.time()
        await self._refresh_whitelist_if_needed()

        try:
            entries = json.loads(raw_message)
        except json.JSONDecodeError:
            logger.warning("failed to decode ws message, skipping")
            return

        if not isinstance(entries, list):
            return

        for entry in entries:
            symbol = entry.get("s")
            close_price = entry.get("c")
            if not symbol or close_price is None:
                continue
            if symbol not in self._whitelist:
                continue

            price = float(close_price)
            self._buffer.add_price(symbol, price)

            # обновляем кэш цены в Redis — читает его outcome_tracker
            try:
                await self._redis.set_price(symbol, price)
            except Exception:
                logger.warning("failed to update price cache for %s", symbol, exc_info=True)

            price_change_pct = check_pump_candidate(symbol, self._buffer)
            if price_change_pct is not None:
                # Не блокируем чтение потока — анализ уходит в фон
                asyncio.create_task(self._handle_candidate(symbol, price_change_pct))

    async def _health_check_loop(self, ws) -> None:
        """Форсирует закрытие соединения, если тишина дольше допустимой — вызовет reconnect в основном цикле."""
        while True:
            await asyncio.sleep(CONFIG.ws_health_check_interval_sec)
            silence = time.time() - self._last_message_ts
            if silence > CONFIG.ws_silence_timeout_sec:
                logger.warning("no ws messages for %.0fs, forcing reconnect", silence)
                await ws.close()
                return

    async def run_forever(self) -> None:
        backoff = CONFIG.reconnect_backoff_start_sec

        while True:
            try:
                logger.info("connecting to %s", STREAM_URL)
                async with websockets.connect(STREAM_URL, ping_interval=20, ping_timeout=20) as ws:
                    self._last_message_ts = time.time()
                    backoff = CONFIG.reconnect_backoff_start_sec  # сброс backoff после успешного коннекта

                    health_task = asyncio.create_task(self._health_check_loop(ws))
                    try:
                        async for message in ws:
                            await self._process_message(message)
                    finally:
                        health_task.cancel()

            except (ConnectionClosed, OSError) as exc:
                logger.warning("ws connection lost (%s), reconnecting in %.1fs", exc, backoff)
            except Exception:
                logger.exception("unexpected ws error, reconnecting in %.1fs", backoff)

            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, CONFIG.reconnect_backoff_max_sec)
