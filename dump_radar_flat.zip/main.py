"""
Точка входа процесса market_watcher.

Запускает две долгоживущие asyncio-задачи параллельно в одном event loop:
- symbol_universe_loop — обновляет whitelist раз в сутки (+ сразу при старте)
- MiniTickerClient.run_forever — читает поток цен и создаёт сигналы

Это первый из трёх процессов (market_watcher, telegram_notifier,
outcome_tracker) — он не отправляет сообщения в Telegram и не проверяет
исходы сигналов, только детектирует и пишет в SQLite.
"""

import asyncio
import logging
import os

import aiohttp

from config import CONFIG
from db import init_db
from redis_client import RedisClient
from symbol_universe import symbol_universe_loop
from ws_client import MiniTickerClient

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("main")


async def main() -> None:
    os.makedirs(os.path.dirname(CONFIG.sqlite_path) or ".", exist_ok=True)
    await init_db(CONFIG.sqlite_path)

    redis_client = RedisClient()

    async with aiohttp.ClientSession() as http_session:
        ws_client = MiniTickerClient(redis_client, http_session)

        try:
            await asyncio.gather(
                symbol_universe_loop(http_session, redis_client),
                ws_client.run_forever(),
            )
        finally:
            await redis_client.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("shutting down market_watcher")
