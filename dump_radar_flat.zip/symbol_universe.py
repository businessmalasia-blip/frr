"""
Формирование и периодическое обновление whitelist отслеживаемых пар.

Логика: берём все активные (TRADING) USDT-M бессрочные фьючерсы с Binance,
пересекаем с монетами капой $100M+ с CoinGecko, обрезаем до
max_monitored_symbols (по умолчанию 200). Результат кладём в Redis, откуда
его читает ws_client при фильтрации входящего потока miniTicker.

Работает как долгоживущая asyncio-задача с периодическим sleep — не блокирует
основной цикл чтения WebSocket.
"""

import asyncio
import logging

import aiohttp

from config import CONFIG
from exchange_client import ExchangeClient, CoinGeckoClient
from redis_client import RedisClient

logger = logging.getLogger("symbol_universe")


async def build_whitelist(session: aiohttp.ClientSession) -> set[str]:
    exchange = ExchangeClient(session)
    coingecko = CoinGeckoClient(session)

    exchange_info = await exchange.get_exchange_info()
    active_symbols = {
        s["symbol"]
        for s in exchange_info.get("symbols", [])
        if s.get("status") == "TRADING"
        and s.get("contractType") == "PERPETUAL"
        and s.get("quoteAsset") == "USDT"
    }

    large_cap_bases = await coingecko.get_symbols_with_min_market_cap(CONFIG.min_market_cap_usd)

    # Сопоставляем base asset (например BTC) с полным символом фьючерса (BTCUSDT)
    matched = set()
    for symbol in active_symbols:
        base = symbol.removesuffix("USDT")
        if base in large_cap_bases:
            matched.add(symbol)

    if len(matched) > CONFIG.max_monitored_symbols:
        # Без дополнительного критерия сортировки просто обрезаем детерминированно
        # (алфавитно) — для MVP не критично, кого именно отсечь на границе лимита.
        matched = set(sorted(matched)[: CONFIG.max_monitored_symbols])

    logger.info(
        "symbol universe built: %d active perpetuals, %d large-cap matches, %d after limit",
        len(active_symbols), len(large_cap_bases & {s.removesuffix('USDT') for s in active_symbols}), len(matched),
    )
    return matched


async def symbol_universe_loop(session: aiohttp.ClientSession, redis_client: RedisClient) -> None:
    """Долгоживущая задача: обновляет whitelist сразу при старте, затем раз в N часов."""
    while True:
        try:
            whitelist = await build_whitelist(session)
            if whitelist:
                await redis_client.set_whitelist(whitelist)
            else:
                logger.warning("built empty whitelist, keeping previous one in Redis")
        except Exception:
            logger.exception("failed to refresh symbol universe, keeping previous whitelist")

        await asyncio.sleep(CONFIG.symbol_universe_refresh_hours * 3600)
