"""
REST-клиент к Binance USDT-M Futures.

Это единственный модуль, завязанный на конкретную биржу. Если в будущем
понадобится Bybit/OKX — меняется только этот файл, остальная архитектура
(event loop, буферы, детекторы) остаётся как есть.

Жёсткое правило проекта: все сетевые вызовы асинхронные. Здесь используется
aiohttp.ClientSession, ни одного синхронного requests-вызова.
"""

import aiohttp

from config import CONFIG


class ExchangeClient:
    def __init__(self, session: aiohttp.ClientSession):
        self._session = session
        self._base = CONFIG.binance_fapi_base

    async def get_exchange_info(self) -> dict:
        """Список всех фьючерсных символов и их статус (TRADING/BREAK/...)."""
        url = f"{self._base}/fapi/v1/exchangeInfo"
        async with self._session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def get_klines(self, symbol: str, interval: str, limit: int) -> list:
        """
        Возвращает свечи в формате Binance kline:
        [open_time, open, high, low, close, volume, close_time, quote_volume, ...]
        """
        url = f"{self._base}/fapi/v1/klines"
        params = {"symbol": symbol, "interval": interval, "limit": limit}
        async with self._session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def get_current_price(self, symbol: str) -> float:
        url = f"{self._base}/fapi/v1/ticker/price"
        params = {"symbol": symbol}
        async with self._session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            data = await resp.json()
            return float(data["price"])


class CoinGeckoClient:
    """
    Binance Futures API не отдаёт капитализацию монеты, поэтому фильтрация
    по $100M+ капе делается через CoinGecko отдельным REST-запросом,
    раз в сутки при обновлении symbol_universe.

    Важное ограничение: сопоставление идёт по base-asset тикеру (например BTC
    из BTCUSDT), что при коллизии тикеров между разными монетами может дать
    неточность. Для MVP это допустимо, но при расширении списка стоит
    сверять по id/названию, а не только по символу.
    """

    def __init__(self, session: aiohttp.ClientSession):
        self._session = session
        self._base = CONFIG.coingecko_base

    async def get_symbols_with_min_market_cap(self, min_cap_usd: float) -> set[str]:
        """
        Возвращает множество base-asset тикеров (верхний регистр, например 'BTC'),
        чья капитализация >= min_cap_usd. Проходит по страницам, пока не
        встретит монету с капой ниже порога (список CoinGecko отсортирован
        по убыванию капы для market_cap_desc).
        """
        result: set[str] = set()
        page = 1
        per_page = 250
        url = f"{self._base}/coins/markets"

        while True:
            params = {
                "vs_currency": "usd",
                "order": "market_cap_desc",
                "per_page": per_page,
                "page": page,
                "sparkline": "false",
            }
            async with self._session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                resp.raise_for_status()
                data = await resp.json()

            if not data:
                break

            stop = False
            for coin in data:
                cap = coin.get("market_cap") or 0
                if cap < min_cap_usd:
                    stop = True
                    break
                symbol = coin.get("symbol", "").upper()
                if symbol:
                    result.add(symbol)

            if stop or len(data) < per_page:
                break
            page += 1

        return result
